Notion Second Brain OS - Duplicate Link:
https://notion.so/sample-second-brain-template
Enjoy!