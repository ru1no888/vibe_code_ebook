# Next.js SaaS Starter Kit

Full stack starter kit with authentication and payment.